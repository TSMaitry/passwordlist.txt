/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Add All Friends As Group Member";
var dirName="iyftjyg";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.not_complete="Friend list extraction is not complete. Please wait until friend list extraction is complete.";
messages.success_msg="Add all friends as group member executed successfully .";
messages.delay_set="Delay time is set to one second.";
messages.invalid_delay="Delay time is invalid number.";
messages.invalid_group_id="Group ID is invalid number.";
messages.confirm_msg="Do you want to continue ?";
messages.invalid_delay_time='Delay time is invalid. Please enter valid delay time.';
messages.make_sure_you_are_logged='Make sure that you are logged into your Facebook account.';
messages.added_as_member="Friend is added as a group member.";

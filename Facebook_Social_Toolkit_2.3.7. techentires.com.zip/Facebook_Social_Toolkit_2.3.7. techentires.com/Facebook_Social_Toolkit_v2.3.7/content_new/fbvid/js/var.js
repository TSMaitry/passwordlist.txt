/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="fbvid";
var targetDivId='fstParentDiv';
var toolTitle = "Facebook Video Downloader";
var messages={}
messages.unable_to_generate= "Unable to generate download link for this video.";
messages.enter_correct_url="Entered URL is Facebook post URL. Please enter URL of Facebook video.";
messages.generating_link='Please wait, generating download link.';
messages.nothing_to_extract= "Nothing to extract. Please enter another URL.";
messages.doesn_not_belong= "URL entered by you doesn't belong to Facebook.com.";
messages.enter_valid= "Please Enter a valid URL.";

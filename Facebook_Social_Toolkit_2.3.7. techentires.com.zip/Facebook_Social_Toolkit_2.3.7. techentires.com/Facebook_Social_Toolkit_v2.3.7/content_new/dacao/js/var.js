/*
Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
See license file for more information
Contact developers at mr.dinesh.bhosale@gmail.com
*/
var toolTitle='Unlike All Facebook Pages';
var dirName="dacao";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.unable_to_find='Unable to find comments to delete. Make sure you are running this tool on correct page.';
messages.no_comments_found="No comments found.";
messages.no_post_id='Unable to find post ID.';
messages.confirm="Are you sure you want to delete all comments on this page\? Once it is done it can't be undone.";
messages.incorrect_input="Incorrect input.";
messages.all_deletable_deleted="All deletable comments are now deleted. Please refresh the page after few seconds.";

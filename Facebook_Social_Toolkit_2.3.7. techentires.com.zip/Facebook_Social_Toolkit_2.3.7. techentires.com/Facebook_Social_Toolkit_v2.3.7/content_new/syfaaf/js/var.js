/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Suggest Your Friends To Add Another Friend";
var dirName="syfaaf";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.invalid_id="Invalid friend id";
messages.suggested="All friends are suggested. It might take a while for suggestions to appear.";
messages.delay="Delay time is set to one second.";
messages.not_complete="Friend list extraction is not complete. Please wait until friend list extraction is complete.";
messages.confirm_msg="Are you sure you want to suggest your friends to another friend ?";
messages.incorrect_friend_id='Make sure you have entered correct friend ID.';
messages.invalid_delay='Delay time is invalid. Please enter valid delay time.';

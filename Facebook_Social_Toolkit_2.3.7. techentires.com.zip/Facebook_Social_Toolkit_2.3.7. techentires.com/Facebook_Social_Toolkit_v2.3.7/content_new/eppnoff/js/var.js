/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle = "Extract Public Phone Numbers Of Facebook Friends";
var dirName = "eppnoff";
var targetFrameId = 'fstFrameDiv';
var targetDivId = 'fstParentDiv';
var messages={};
messages.extraction_not_complete="Friend list extraction is not complete. Please wait until friend list extraction is completed.";
messages.unable_to_detect="Unable to detect friend IDs";
messages.extraction_completed="Phone number extraction completed.";
messages.wait='Please wait, extracting phone numbers';
messages.started="Phone number extraction started.";

/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var toolTitle='Unlike All Facebook Pages';
var dirName="iafsao";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={}
messages.ignored="All suggestions are ignored.";

/*
 * Copyright(c) 2014-2016 Dinesh Rajkumar Bhosale of getmyscript.com
 * See license file for more information
 * Contact developers at mr.dinesh.bhosale@gmail.com
 * */
var dirName="uafgao";
var targetFrameId='fstFrameDiv';
var targetDivId='fstParentDiv';
var messages={};
messages.not_complete="Group extraction is not complete. Please wait until group extraction is complete. Also make sure that you are member of at least one Facebook group.";
messages.are_you_member="Are you sure you are member of Facebook groups?";
messages.all_unfollowed="All groups are unfollowed and notifications turned off for all Facebook groups.";
messages.confirm_msg="Are you sure you want to unfollow all groups and turn off notifications for all groups at once?";

var backgroundMessages={}
backgroundMessages.installed=extensionName+" "+manifest.version+" is installed.";